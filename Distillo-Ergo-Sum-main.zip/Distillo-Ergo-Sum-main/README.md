# Distillo Ergo Sum

## Heterogeneous knowledge distillation in medical computer vision

Final project for the **Advanced Machine Learning** exam, taught by Prof. **Fabio Galasso** at **Sapienza University of Rome** in A.Y. 2023/24

### Reproducibility

#### Environment

See instructions in [env.md](https://github.com/Astronauts-Making-Limoncello/Distillo-Ergo-Sum/blob/main/env.md) to create an Python virtual environment for the project

#### Data pre-processing

COMING SOON

#### Training

COMING SOON

#### Inference

COMING SOON

# Group members
- <a href=https://github.com/GiacomoBelliniStudent>Giacomo Bellini</a>
- <a href=https://github.com/ludomazza>Ludovica Mazza</a>
- <a href=https://github.com/MRampo>Matteo Rampolla</a>
- <a href=https://github.com/dansolombrino>Daniele Solombrino</a>
